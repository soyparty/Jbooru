<?php
echo file_get_contents("imagedata.json");
?>