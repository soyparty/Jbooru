<?php
echo file_get_contents("list.txt");
?>