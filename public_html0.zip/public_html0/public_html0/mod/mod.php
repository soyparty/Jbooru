<head>
    <title>Moderator Portal</title>
    <link rel="icon" type="image/x-icon" href="/datasrc/icon.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
 <link href="/datasrc/style.css" rel="stylesheet">
</head>

<h1 class = "headings" id = "user"></h1>


<?php
require '/auth.php';
if(AUTH("","") === true) {
   echo "<script>document.getElementById('user').innerText = 'success';</script>";
}
else {
       echo "<script>document.getElementById('user').innerText = 'failure';</script>";
}
?>