<head>
    <title>New Booru Posts</title>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="/datasrc/icon.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
 <link href="/datasrc/style.css" rel="stylesheet" />
</head>
<body onload = "loadall()">
<div id="options" style = "border-bottom:solid 3px gray;">
  <a href = "index.html">Home</a>
  <a href="post.php">Upload</a>
  <a href="/pages.php">Posts</a>
  <a href="/contact.html">Contacts</a>
  <a href="/mod/login.html">Login</a>
  </div>
  <div id = "headers" style = "border-bottom:2px white solid;">
  <h1 class = "headings" style = "border-bottom:none;text-align:left;">Posts</h1>
  <small>This is a collection of all posts on New Booru:</small>
  </div>
  <div id = "posts" style = "float:left;width:80vw;" ></div>
    <script src = "/datasrc/credit.js"></script>
  </body>
  <script>
      function loadall() {
              $.get("./db/img.php", function(data, status){
      const datas = data.split("\n");
      const data2 = datas.reverse();
      data2.shift();
      const posts = document.getElementById("posts");
      for(let i = 0; i < data2.length; i++) {
          let imgs = document.createElement("img");
          let imghref = document.createElement("a");
          imghref.href = "thread.php?" + data2[i];
          imgs.src = data2[i];
          imgs.style.maxWidth = "20vw";
          imgs.style.border = "1px solid white";
          imgs.style.maxHeight = "25vh";
          imghref.appendChild(imgs);
          posts.appendChild(imghref);
      }

          });
      }
  </script>