<head>
    <title id = "titles">New Booru - Undefined</title>
    <link rel="icon" type="image/x-icon" href="/datasrc/icon.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
 <link href="/datasrc/style.css" rel="stylesheet" />
</head>
<html>
    <body onload = "pageload();">
    <div id="options" style = "border-bottom:solid 3px gray;">
  <a href = "index.html">Home</a>
  <a href="post.php">Upload</a>
  <a href="/pages.php">Posts</a>
  <a href="/contact.html">Contacts</a>
  <a href="/mod/login.html">Login</a>
  </div>
  <br>
  <div id = "alltags" style = "position:absolute;left:30vw;width:8%;overflow-wrap: break-word;border:3px solid white;overflow: hidden;overflow-y:auto">

  </div>
  <div id = "content" style = "position:relative;left:40vw;display:block;margin: auto;border-left:4px solid white;border-bottom:4px solid white;">
     <img  id = "mainimg"  style = "max-width:50vw;max-height:50vh;">
     <br>
  </div>
  <h1 style = "left:5vh; width:100%; border-bottom:3px solid white;">Comments:</h1>
  <div id = "comments"> <form method = "post" action = "comment.php"><input type = "text" placeholder = "Username here..."name = "username"><textarea name = "comment-content" rows = "3" columns = "50" maxlength = "250" style = "resize:none" placeholder="Comment here..." ></textarea> <br>
  <input type = "number" name = "num" id = "numbers" style = "display:none">
  <input type = "text" name = "url" id = "urls" style = "display:none">
  <small>Tripcode:</small> <input type = "checkbox" name = "tripcode"> <br>
  <input type = "submit" value = "Comment">
</form> <br> </div>
<script src = "/datasrc/credit.js"></script>
  </body>
</html>

<script>

function pageload() {
        var a = window.location.href;
let link = a.split('?')[1];
console.log(link);
$.get(link).done(function () {
      document.getElementById("mainimg").src = link;
      const wait = setTimeout(function(){ var heights = document.getElementById("mainimg").height; document.getElementById("alltags").style.height = heights;}, 200);
     
      
      
      
}).fail(function () {
       window.location.href = "/err/404.html";
});

var stringToColor = (string, saturation = 100, lightness = 75) => {
  let hash = 0;
  for (let i = 0; i < string.length; i++) {
hash = string.charCodeAt(i) + ((hash << 5) - hash);
hash = hash & hash;
  }
  return `hsl(${(hash % 360)}, ${saturation}%, ${lightness}%)`;
}
var stringTodarkColor = (string, saturation = 100, lightness = 30) => {
  let hash = 0;
  for (let i = 0; i < string.length; i++) {
hash = string.charCodeAt(i) + ((hash << 5) - hash);
hash = hash & hash;
  }
  return `hsl(${(hash % 360)}, ${saturation}%, ${lightness}%)`;
}


  $.get("./db/data.php", function(data, status){
    const obj = JSON.parse(data);
 const tagarea = document.getElementById("alltags");
index = obj.findIndex(data => data.image == link);
const tags1 = obj[index].tag.replace("\\", " ").split(" ");
document.getElementById("numbers").value = index;
document.getElementById("urls").value = window.location.href;
if(tags1.length >=3 ) {
 document.title = "Post: " + tags1[0] + ", " + tags1[1] + ", " + tags1[2] +"... (" + tags1.length + ")";
}
else {
    document.title = "Post: " + tags1[0] + "... "  + " (" + tags1.length + ")";
}
for(let i = 0; i < tags1.length; i++) {
     const para = document.createElement("b");
     para.innerText = tags1[i];
tagarea.appendChild(para);
tagarea.appendChild(document.createElement("br"));
}
const comment = obj[index].comments.replace("\\", "").split(":");

for(let x = comment.length; x > 0; x -= 2) {

  if (x != comment.length) {
let comdiv = document.createElement("div");
let u2 = document.createElement("small");
let u = document.createElement("u");
let p = document.createElement("p");
let span = document.createElement("span");
comdiv.className = "comment";
if(comment[x].includes("|")) {
    u2.innerText = comment[x].split("|")[1].replace(/(.{2})./g,"$1").replaceAll("\\", " ") + ":";
    u2.style.borderRadius = "5px";
    u2.style.backgroundColor = stringToColor(u2.innerText);
    u2.style.fontSize = "10px";
    u2.style.color = stringTodarkColor(u2.innerText);
    u2.style.width = "3vw";
    u.innerText = comment[x].split("|")[0].replaceAll("\\", " ") + " ";
}
else {
u.innerText = comment[x].replaceAll("\\", " ") + ":";
}
p.innerText = comment[x+1].replaceAll("\\", " ");
span.className = "div.comment.span";
span.appendChild(u);
if(comment[x].includes("|")) {
    span.appendChild(u2);
}
span.appendChild(document.createElement("br"));
span.appendChild(p);
comdiv.appendChild(span);
document.getElementById("comments").appendChild(comdiv);
document.getElementById("comments").appendChild(document.createElement("br"));
}}
}).fail(function () {
       window.location.href = "/err/404.html";
});




    }
    

</script>