let url = window.location.pathname;
var filename = url.substring(url.lastIndexOf('/')+1);
    const para = document.createElement("div");
    para.className = "credit";
const p = document.createElement("p");
p.innerText = "Using Jbooru V 1.0.0";
const s = document.createElement("small");
s.innerText ="Copyright © Jbooru 1.0.0; Created by Admin@soyja.cc;";
const x = document.createElement("small")
x.innerText = "All rights reserved."

if(filename == "index.html" || filename.includes("pages.php")) {
    para.style.position = "relative";
    para.appendChild(document.createElement("br"));
    para.appendChild(document.createElement("br"));
}

if(filename.includes("thread.php") ) {
        para.appendChild(document.createElement("br"));
    para.appendChild(document.createElement("br"));
    para.style.position = "relative";
    para.style.borderTop = "none";
}
if(filename != "index.html" && || filename.includes("pages.php") === false) {
para.appendChild(p);
if(filename.includes("thread.php") === false ) {
para.style.position = "fixed";

}
}
para.appendChild(s)
para.appendChild(document.createElement("br"));
para.appendChild(x);

// Append to body:
document.body.appendChild(para);