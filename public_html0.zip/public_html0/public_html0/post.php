<head>
    <title>Upload</title>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="/datasrc/icon.png">
    <link rel="icon" type="image/x-icon" href="/icon.png">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
 <link href="/datasrc/style.css" rel="stylesheet" />
</head>
<html>
<div class = "upload">
<h1><u>Upload to booru:</u></h1>
<p><u>Upload your images here.</u></p>
<small>Image Tags here:</small> <input placeholder = "Separate each tag with a space" type = "text" id = "tags" size = "20"><br>
<span ><small>1:</small> <input type = "file" id = "inp"></span> <br>
<canvas id = "canvas" ></canvas> <br>
<button onclick = "submit2()">Upload</button>
</div>
<div class = "other">
<a href="/index.html">Home</a>
  <a href="post.php">Upload</a>
  <a href="/pages.php?1">Posts</a>
  <a href="/contact.html">Contacts</a>
  <a href="/mod/login.html">Login</a>
</div>

</html>
  <script src = "/datasrc/credit.js"></script>
<script>
document.getElementById('inp').onchange = function(e) {
  var img = new Image();
  img.onload = draw;
  img.onerror = failed;
  img.src = URL.createObjectURL(this.files[0]);
};
function draw() {
  var canvas = document.getElementById('canvas');
  canvas.width = this.width;
  canvas.height = this.height;
  var ctx = canvas.getContext('2d');
  ctx.drawImage(this, 0,0);
}
function failed() {
  console.error("The provided file couldn't be loaded as an Image media");
}

function submit2() {
    const canvas = document.getElementById("canvas");
  $.post("post.php",
  {
    image: canvas.toDataURL("image/png"),
    tags: document.getElementById("tags").value
  },
  function(data, status){
      const scripts = data.split("\n");
      if(scripts[scripts.length - 1] !== "Error! No data found") {
      window.location.href = "/thread.php?" + scripts[scripts.length - 1];
      }
      else {
          alert("Error! No data found");
      }
  });
}

</script>
<script id = "loadup"></script>
<?php
if($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["image"]) && isset($_POST["tags"])) {
    if (empty($_POST["image"]) || empty($_POST["tags"])) {
echo 'Error! No data found';
    }
    else {
    $i2 = 25;
    $filename = "/src/".getName($i2).".png";
$image = file_get_contents($_POST["image"]);
file_put_contents(".".$filename, $image);
$images = Array(
"image" => $filename,
"tag" => addslashes($_POST["tags"]),
"comments" => Array(":AutoBot:Reminder, do not violate the rules, or your ip may be blocked."),
'ip' => $_SERVER["REMOTE_ADDR"]
);
$test = file_get_contents("./db/imagedata.json");
if(empty($test)) {
$json = json_encode($images);
}
else {
    $json = file_get_contents("./db/imagedata.json") . "," . json_encode($images);
}
file_put_contents("./db/imagedata.json", "[". str_replace("]"," ",str_replace("["," ",$json))."]");
file_put_contents("./db/list.txt", $filename . "\n", FILE_APPEND);
echo $filename;
    }
}

function getName($n) {
    $characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $randomString = '';
 
    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }

 
    return $randomString;
}

function compress($source, $destination, $quality) {

    $info = getimagesize($source);

    if ($info['mime'] == 'image/jpeg') 
        $image = imagecreatefromjpeg($source);

    elseif ($info['mime'] == 'image/gif') 
        $image = imagecreatefromgif($source);

    elseif ($info['mime'] == 'image/png') 
        $image = imagecreatefrompng($source);

    imagejpeg($image, $destination, $quality);

    return $destination;
}

?>