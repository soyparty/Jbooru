<?php
// Do not mess with this file.
// This authenticates user interactions with the server
// Editing this may cause uploads, comments, and profile editor to fail.

if($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["user"]) && empty($_POST["user"]) === false && isset($_POST["pass"]) && empty($_POST["pass"]) === false) {
    if(AUTH($_POST["user"], $_POST["pass"]) === true) {
        echo "Successful Login! Redirecting...";
                header("Location: " ."./mod/mod.php", true, 200);  
exit();  
        
    }
    else {
        echo "Incorrect Credentials... Redirecting...";
        sleep(1);
        header("Location: " . "./mod/mod.php", true, 200); 
exit();  
    }
}

if($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["logout"]) && $_POST["logout"] === "true")
{
    if(empty($_SESSION["justification"]) === false) 
    {
        logout();
        echo "t";
        
    } 
    }
function salt($seed) {
    $IntSeed = crc32($seed);
    $IntSeed1 = crc32($seed . $seed);
    $IntSeed2 = crc32(strrev($seed));
    return toAlpha($IntSeed1) . $IntSeed . toAlpha($IntSeed) . $IntSeed2 . toAlpha($IntSeed2) . $IntSeed1;
}
function logout() {
    session_start();
    session_unset();
    session_destroy();
}
function AUTH($user, $pass) {
session_start();
if(empty($_SESSION["justification"])) {
$json = json_decode(file_get_contents("./mod/mod.json"));
for ($x = -1; $x <= count($json); $x++) {
  if($json[$x]->user === $user && $json[$x]->pass === $pass) {
  $encrypted = openssl_encrypt($_SERVER["REMOTE_ADDR"],"AES-128-ECB", salt($user." ".$pass));
  $_SESSION["justification"] = $encrypted;
  return true;
}
}

}

elseif(empty($_SESSION["justification"]) === false && empty($user) === false && empty($pass) === false) {
    $q = false;
    $json = json_decode(file_get_contents("./mod/mod.json"));
for ($x = -1; $x <= count($json); $x++) {
$decrypted = openssl_decrypt($_SESSION["justification"] ,"AES-128-ECB",salt($json[$x]->user ." ". $json[$x]->pass));
if($decrypted === $_SERVER["REMOTE_ADDR"]) {
    $q = true;
}
}
if($q === false) {return false;} if($q === true) {return true;}
}

}

function toAlpha($data){
    $alphabet =   array('a','*','C','!','E','~','g','%','I',':','k','>','M','=','o','+','Q','-','s','_','U','@','w','^','Y','.');
    $alpha_flip = array_flip($alphabet);
    if($data <= 25){
      return $alphabet[$data];
    }
    elseif($data > 25){
      $dividend = ($data + 1);
      $alpha = '';
      $modulo;
      while ($dividend > 0){
        $modulo = ($dividend - 1) % 26;
        $alpha = $alphabet[$modulo] . $alpha;
        $dividend = floor((($dividend - $modulo) / 26));
      } 
      return $alpha;
    }
}
?>