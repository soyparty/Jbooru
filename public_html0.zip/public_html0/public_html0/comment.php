<?php
// This allows commenting
// To edit filters, simply modify the AUTOMOD() function
// in line 11, you can edit the salt password, so people can't crack your tripcodes.
include "auth.php";
if($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["username"]) && isset($_POST["comment-content"]) && isset($_POST["num"]) && isset($_POST['url']))  {
    if(strlen($_POST["username"]) >= 3 && strlen($_POST["comment-content"]) >= 3 && strlen($_POST["username"]) < 25 && strlen($_POST["comment-content"]) < 250) {
        $user = str_replace("|","",$_POST["username"]);
        $user2 = $user;
            if(isset($_POST["tripcode"])) {
        $user = $user ."|".str_replace("=","",openssl_encrypt($_SERVER["REMOTE_ADDR"],"AES-128-ECB", salt("XIjqG1E0mTY6daelysIngGlFy4XuIlWr")));
    }
     $json = json_decode(file_get_contents("./db/imagedata.json"));
     $json[$_POST["num"]]->comments = str_replace("\n", "", $json[$_POST["num"]]->comments  .":
     ".  addslashes(str_replace(":", "", $user)) . ":" .  addslashes(str_replace(":", "", $_POST["comment-content"])));
     file_put_contents("./db/imagedata.json", json_encode($json));
     header("location:" . $_POST["url"]);
}
else {
    echo "<script>alert('error');history.go(-1)</script>";
}
}



?>